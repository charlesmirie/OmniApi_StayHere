﻿using System;
using System.Data;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Http;
using BRBase;
using Newtonsoft.Json;
using OmniApi.CoreLibraries;
using Swashbuckle.Swagger.Annotations;
using WebApi.Jwt.Filters;
using WebApi.Jwt.Models;

namespace CoreOmniApi.Controllers
{
    //[JwtAuthentication]
    public class showCaseController : ApiController
    {

        /// <summary>
        /// This API will return all the showCase and their specific details.
        /// APIResponse '00' Means Success
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns>
        [HttpPost]
        [SwaggerResponseRemoveDefaults]
        [SwaggerResponse(300057, "Invalid Request Parameters")]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(00, "APIResponse '00' Means Success")]
        public IHttpActionResult AddShowCase(AddShowCase myData)
        {
            bool Valid = false;
            UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();

            //START .... Log Request   
            string AuditRespo = string.Empty;
            string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
            /*Log Request In File  .... START .... */
            string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
            CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, myData.ToString(), myData);
            /*Log Request In File  .... END ....*/

            /*Log Request In the DB  .... START .... */
            string strParams = "usrData";
            object strParamValues = myData;
            UserInfo usrInfo_ = CoreOmniApiBase.GetDbParameter();
            AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo_, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

            Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
            var v = regex.Match(AuditRespo);
            string UniqueAuditID = v.Groups[1].ToString();
            /*Log Request In the DB  .... END .... */
            //END .... Log Request 

            if (myData == null)
            {
                DataSet resp = CoreOmniApiBase.GenResponse("099", "300057", "Invalid Request Parameters");
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, resp, resp);
            }

            try
            {
                BRDataSet ds_AddshowCase = new BRDataSet();
                // BRDataSet ds_APIResponse = new BRDataSet();
                Valid = OmniCore.AddShowCase(usrInfo, "", myData.showCaseTitle, myData.showCaseMessage, myData.imageID, myData.userID, 1, 1, out ds_AddshowCase);
                ds_AddshowCase.Namespace = null;
                //ds_APIResponse = ds_AddshowCase;

                //START .... Log Response     
                /*Log Response In File  .... START .... */
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, JsonConvert.SerializeObject(ds_AddshowCase).ToString(), JsonConvert.SerializeObject(ds_AddshowCase));
                /*Log Response In File  .... END ....*/

                /*Log Response In the DB  .... START .... */
                string strParamsResp = "APIResponse";
                string[] strParamValuesResp = { JsonConvert.SerializeObject(ds_AddshowCase) };
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                /*Log Response In the DB  .... END .... */
                //END .... Log Response 

                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, ds_AddshowCase, ds_AddshowCase);
            }
            catch (Exception ex)
            {
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, CoreOmniApiBase.GetErrorMessage(ex), CoreOmniApiBase.GetErrorMessage(ex));
            }
        }

        /// <summary> 
        /// Pass: isActive = 0 (To Disable),isActive = 1 (To Enable)
        /// Pass: ActionID = 2 (For Edit), ActionID = 3 (For Delete)
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns>
        public IHttpActionResult EditShowCase(EditShowCase myData)
        {
            bool Valid = false;
            UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();

            //START .... Log Request   
            string AuditRespo = string.Empty;
            string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
            /*Log Request In File  .... START .... */
            string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
            CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, myData.ToString(), myData);
            /*Log Request In File  .... END ....*/

            /*Log Request In the DB  .... START .... */
            string strParams = "usrData";
            object strParamValues = myData;
            UserInfo usrInfo_ = CoreOmniApiBase.GetDbParameter();
            AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo_, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

            Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
            var v = regex.Match(AuditRespo);
            string UniqueAuditID = v.Groups[1].ToString();
            /*Log Request In the DB  .... END .... */
            //END .... Log Request 

            if (myData == null)
            {
                DataSet resp = CoreOmniApiBase.GenResponse("099", "300057", "Invalid Request Parameters");
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, resp, resp);
            }

            try
            {
                BRDataSet ds_EditshowCase = new BRDataSet();
                // BRDataSet ds_APIResponse = new BRDataSet();
                Valid = OmniCore.EditShowCase(usrInfo, myData.showCaseID, myData.showCaseTitle, myData.showCaseMessage, myData.imageID, 2, myData.userID, myData.actionID, out ds_EditshowCase);
                ds_EditshowCase.Namespace = null;
                //ds_APIResponse = ds_EditshowCase;

                //START .... Log Response     
                /*Log Response In File  .... START .... */
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, JsonConvert.SerializeObject(ds_EditshowCase).ToString(), JsonConvert.SerializeObject(ds_EditshowCase));
                /*Log Response In File  .... END ....*/

                /*Log Response In the DB  .... START .... */
                string strParamsResp = "APIResponse";
                string[] strParamValuesResp = { JsonConvert.SerializeObject(ds_EditshowCase) };
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                /*Log Response In the DB  .... END .... */
                //END .... Log Response 

                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, ds_EditshowCase, ds_EditshowCase);
            }
            catch (Exception ex)
            {
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, CoreOmniApiBase.GetErrorMessage(ex), CoreOmniApiBase.GetErrorMessage(ex));
            }
        }

        /// <summary>
        /// Pass: ShowcaseID 
        /// APIResponse '00' Means Success
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns>
        [HttpPost]
        [SwaggerResponseRemoveDefaults]
        [SwaggerResponse(300057, "Invalid Request Parameters")]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(00, "APIResponse '00' Means Success")]
        public IHttpActionResult GetShowCaseByID(GetShowCaseByID myData)
        {
            bool Valid = false;
            UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();

            //START .... Log Request   
            string AuditRespo = string.Empty;
            string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
            /*Log Request In File  .... START .... */
            string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
            CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, myData.ToString(), myData);
            /*Log Request In File  .... END ....*/

            /*Log Request In the DB  .... START .... */
            string strParams = "usrData";
            object strParamValues = myData;
            UserInfo usrInfo_ = CoreOmniApiBase.GetDbParameter();
            AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo_, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

            Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
            var v = regex.Match(AuditRespo);
            string UniqueAuditID = v.Groups[1].ToString();
            /*Log Request In the DB  .... END .... */
            //END .... Log Request 

            if (myData == null)
            {
                DataSet resp = CoreOmniApiBase.GenResponse("099", "300057", "Invalid Request Parameters");
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, resp, resp);
            }

            try
            {
                BRDataSet ds_showCase = new BRDataSet();
                // BRDataSet ds_APIResponse = new BRDataSet();
                Valid = OmniCore.GetShowCaseByID(usrInfo, myData.showCaseID, out ds_showCase);
                ds_showCase.Namespace = null;
                // ds_APIResponse = ds_showCase;

                //START .... Log Response     
                /*Log Response In File  .... START .... */
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, ds_showCase.ToString(), JsonConvert.SerializeObject(ds_showCase));
                /*Log Response In File  .... END ....*/

                /*Log Response In the DB  .... START .... */
                string strParamsResp = "APIResponse";
                string[] strParamValuesResp = { JsonConvert.SerializeObject(ds_showCase) };
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                /*Log Response In the DB  .... END .... */
                //END .... Log Response 

                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, ds_showCase, ds_showCase);
            }
            catch (Exception ex)
            {
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, CoreOmniApiBase.GetErrorMessage(ex), CoreOmniApiBase.GetErrorMessage(ex));
            }
        } 
        
        [HttpPost]
        [SwaggerResponseRemoveDefaults]
        [SwaggerResponse(300057, "Invalid Request Parameters")]
        [SwaggerResponse(500, "Internal Server Error")]
        [SwaggerResponse(00, "APIResponse '00' Means Success")]
        public IHttpActionResult GetAllShowCase(GetAllShowCase myData)
        {
            bool Valid = false;
            UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();

            //START .... Log Request   
            string AuditRespo = string.Empty;
            string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
            /*Log Request In File  .... START .... */
            string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
            CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, myData.ToString(), myData);
            /*Log Request In File  .... END ....*/

            /*Log Request In the DB  .... START .... */
            string strParams = "usrData";
            object strParamValues = myData;
            UserInfo usrInfo_ = CoreOmniApiBase.GetDbParameter();
            AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo_, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

            Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
            var v = regex.Match(AuditRespo);
            string UniqueAuditID = v.Groups[1].ToString();
            /*Log Request In the DB  .... END .... */
            //END .... Log Request 

            if (myData == null)
            {
                DataSet resp = CoreOmniApiBase.GenResponse("099", "300057", "Invalid Request Parameters");
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, resp, resp);
            }

            try
            {
                BRDataSet ds_showCase = new BRDataSet();
                // BRDataSet ds_APIResponse = new BRDataSet();
                Valid = OmniCore.GetAllShowCase(usrInfo, out ds_showCase);
                ds_showCase.Namespace = null;
                // ds_APIResponse = ds_showCase;

                //START .... Log Response     
                /*Log Response In File  .... START .... */
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, ds_showCase.ToString(), JsonConvert.SerializeObject(ds_showCase));
                /*Log Response In File  .... END ....*/

                /*Log Response In the DB  .... START .... */
                string strParamsResp = "APIResponse";
                string[] strParamValuesResp = { JsonConvert.SerializeObject(ds_showCase) };
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                /*Log Response In the DB  .... END .... */
                //END .... Log Response 

                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, ds_showCase, ds_showCase);
            }
            catch (Exception ex)
            {
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, CoreOmniApiBase.GetErrorMessage(ex), CoreOmniApiBase.GetErrorMessage(ex));
            }
        }
    }
}
