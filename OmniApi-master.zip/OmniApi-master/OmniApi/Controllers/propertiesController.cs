﻿using System;
using System.Data;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Http;
using BRBase;
using Newtonsoft.Json;
using OmniApi.CoreLibraries;
using Swashbuckle.Swagger.Annotations;
using WebApi.Jwt.Filters;
using WebApi.Jwt.Models;

namespace CoreOmniApi.Controllers
{
    //[JwtAuthentication]
    public class propertiesController : ApiController
    {

        /// <summary>
        /// This API will return all the GetAllPropertiesList and their specific details.
        /// APIResponse '00' Means Success
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns> 


        [HttpPost]
        [SwaggerResponseRemoveDefaults] 
        public IHttpActionResult AddPropertyType(AddPropertyType myData)
        {
            bool Valid = false;
            UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();

            //START .... Log Request   
            string AuditRespo = string.Empty;
            string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
            /*Log Request In File  .... START .... */
            string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
            CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, myData.ToString(), myData);
            /*Log Request In File  .... END ....*/

            /*Log Request In the DB  .... START .... */
            string strParams = "usrData";
            object strParamValues = myData;
            UserInfo usrInfo_ = CoreOmniApiBase.GetDbParameter();
            AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo_, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

            Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
            var v = regex.Match(AuditRespo);
            string UniqueAuditID = v.Groups[1].ToString();
            /*Log Request In the DB  .... END .... */
            //END .... Log Request 

            if (myData == null)
            {
                DataSet resp = CoreOmniApiBase.GenResponse("099", "300057", "Invalid Request Parameters");
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, resp, resp);
            }

            try
            {
                BRDataSet ds_GetAllPropertiesList = new BRDataSet();
                BRDataSet ds_APIResponse = new BRDataSet();
                Valid = OmniCore.AddPropertyType(usrInfo, myData.PropertyID, out ds_APIResponse);
                ds_GetAllPropertiesList.Namespace = null;
                ds_APIResponse = ds_GetAllPropertiesList;

                //START .... Log Response     
                /*Log Response In File  .... START .... */
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, ds_GetAllPropertiesList.ToString(), JsonConvert.SerializeObject(ds_GetAllPropertiesList));
                /*Log Response In File  .... END ....*/

                /*Log Response In the DB  .... START .... */
                string strParamsResp = "APIResponse";
                string[] strParamValuesResp = { JsonConvert.SerializeObject(ds_GetAllPropertiesList) };
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                /*Log Response In the DB  .... END .... */
                //END .... Log Response 

                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, ds_GetAllPropertiesList, ds_GetAllPropertiesList);
            }
            catch (Exception ex)
            {
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, CoreOmniApiBase.GetErrorMessage(ex), CoreOmniApiBase.GetErrorMessage(ex));
            }
        }

        /// </summary>
        /// This API will return all the GetAllPropertiesList and their specific details.
        /// APIResponse '00' Means Success
        /// </summary>
        /// <param name="myData"></param>
        /// <returns></returns> 

    }
}

