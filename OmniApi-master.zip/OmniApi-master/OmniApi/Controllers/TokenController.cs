﻿using System;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Http;
using System.Web.Http.Description;
using BR.Configuration;
using BRBase;
using Newtonsoft.Json;
using OmniApi.Classes;
using OmniApi.CoreLibraries;
using Swashbuckle.Swagger.Annotations;
using WebApi.Jwt;
using WebApi.Jwt.Models;


namespace OmniApi.Controllers
{
    /// <summary>
    /// Token API Class
    /// </summary> 
    public class TokenController : ApiController
    {
        readonly string usrKey = BRConfigurationManager.BRAppSettings["usrKey"];

        /// <summary>
        /// This gives you time bound access token to call the allowed APIs
        /// </summary>
        /// <param name="usrData"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        [SwaggerResponseRemoveDefaults]
        [SwaggerResponse(300057, "Invalid Request Parameters")]
        [SwaggerResponse(300058, "Invalid Credentials")]
        [SwaggerResponse(500, "Internal Server Error")]
        [Route("A_RequestConnection")]
        public IHttpActionResult Generate(UserInfoData usrData)
        {
            string consumerKey = string.Empty;
            string consumerSecret = string.Empty;
            long tokenExpiry = Convert.ToInt64(BRConfigurationManager.BRAppSettings["exp"]);
            string Token = string.Empty;
            ReturnResponse returnResponse = new ReturnResponse();
            if (usrData == null)
            {
                returnResponse.WebServiceStatus = "99";
                returnResponse.AccessToken = "";
                returnResponse.TokenExpiry = "";
                returnResponse.ErrorNo = "300057";
                returnResponse.ErrorMessage = "Invalid Request Parameters";

                return new JSONActionResult(JsonConvert.SerializeObject(returnResponse));
            }

            try
            {
                //START .... Log Request   
                string AuditRespo = string.Empty;
                string MethodName = MethodBase.GetCurrentMethod().Name.ToString();
                /*Log Request In File  .... START .... */
                string UniqueAuditID_ = CoreOmniApiBase.UniqueAuditID();
                CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Request.." + UniqueAuditID_, usrData.ToString(), usrData);
                /*Log Request In File  .... END ....*/

                /*Log Request In the DB  .... START .... */
                string strParams = "usrData";
                object strParamValues = usrData;
                UserInfo usrInfo = CoreOmniApiBase.GetDbParameter();
                AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Request", AuditRespo, strParams, strParamValues, "");

                Regex regex = new Regex("<UniqueAuditID>(.*)</UniqueAuditID>");
                var v = regex.Match(AuditRespo);
                string UniqueAuditID = v.Groups[1].ToString();
                /*Log Request In the DB  .... END .... */
                //END .... Log Request 

                if (usrData != null)
                {
                    consumerKey = CoreOmniApiBase.DeCrypt(usrData.ConsumerKey, usrKey);
                    consumerSecret = CoreOmniApiBase.DeCrypt(usrData.ConsumerSecret, consumerKey);

                    if (CheckUser(consumerKey, consumerSecret, usrData))
                    {


                        Token = JwtManager.GenerateToken(consumerKey, tokenExpiry);

                        returnResponse.WebServiceStatus = "00";
                        returnResponse.AccessToken = Token;
                        returnResponse.TokenExpiry = tokenExpiry.ToString();
                        returnResponse.ErrorNo = "";
                        returnResponse.ErrorMessage = "";

                        //START .... Log Request     
                        /*Log Response In File  .... START .... */
                        CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, returnResponse.ToString(), JsonConvert.SerializeObject(returnResponse));
                        /*Log Response In File  .... END ....*/

                        /*Log Response In the DB  .... START .... */
                        string strParamsResp = "APIResponse";
                        string[] strParamValuesResp = { JsonConvert.SerializeObject(returnResponse) };
                        AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                        /*Log Response In the DB  .... END .... */
                        //END .... Log Response 

                        return new JSONActionResult(JsonConvert.SerializeObject(returnResponse));
                    }
                    else
                    {
                        returnResponse.WebServiceStatus = "99";
                        returnResponse.AccessToken = "";
                        returnResponse.TokenExpiry = "";
                        returnResponse.ErrorNo = "300058";
                        returnResponse.ErrorMessage = "Invalid Credentials";

                        //START .... Log Request     
                        /*Log Response In File  .... START .... */
                        CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, returnResponse.ToString(), JsonConvert.SerializeObject(returnResponse));
                        /*Log Response In File  .... END ....*/

                        /*Log Response In the DB  .... START .... */
                        string strParamsResp = "APIResponse";
                        string[] strParamValuesResp = { JsonConvert.SerializeObject(returnResponse) };
                        AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                        /*Log Response In the DB  .... END .... */
                        //END .... Log Response 
                        return new JSONActionResult(JsonConvert.SerializeObject(returnResponse));
                    }

                }
                else
                {
                    returnResponse.WebServiceStatus = "99";
                    returnResponse.AccessToken = "";
                    returnResponse.TokenExpiry = "";
                    returnResponse.ErrorNo = "300058";
                    returnResponse.ErrorMessage = "Invalid Credentials";

                    //START .... Log Request     
                    /*Log Response In File  .... START .... */
                    CoreOmniApiBase.TextFileLogs("StayHereLogs", MethodName + "..Response.." + UniqueAuditID_, returnResponse.ToString(), JsonConvert.SerializeObject(returnResponse));
                    /*Log Response In File  .... END ....*/

                    /*Log Response In the DB  .... START .... */
                    string strParamsResp = "APIResponse";
                    string[] strParamValuesResp = { JsonConvert.SerializeObject(returnResponse) };
                    AuditRespo = OmniCore.fn_APIAuditLog_(usrInfo, MethodName, "Response", AuditRespo, strParamsResp, strParamValuesResp, UniqueAuditID);
                    /*Log Response In the DB  .... END .... */
                    //END .... Log Response 
                    return new JSONActionResult(JsonConvert.SerializeObject(returnResponse));
                }
            }
            catch (HttpResponseException ex)
            {
                //throw new HttpResponseException(HttpStatusCode.Unauthorized);
                CoreOmniApiBase.WriteToLogFile("BR20ErrorLogs", "Generate", ex.Message);
                return CreatedAtRoute(CoreOmniApiBase.OmniApiRoute, new HttpResponseException(HttpStatusCode.Unauthorized), new HttpResponseException(HttpStatusCode.Unauthorized));
            }
        }
         
        private bool CheckUser(string username, string password, UserInfoData usrData)
        {
            DataTable usrInfo = new DataTable();

            DataTable dtUsrData = CoreOmniApiBase.dtFromObject(usrData, "usrData");
            dtUsrData.Rows[0]["ConsumerKey"] = username;
            dtUsrData.Rows[0]["ConsumerSecret"] = password;

            CoreOmniApiBase.gOperatorID = username;
            SpConnMaster.TokenOperatorID = username;
            

            bool ValidUser = CoreOmniApiBase.ValidateUser(dtUsrData);
            return ValidUser;
        }

        /// <summary>
        /// Redirects to Swagger UI
        /// </summary>
        /// <returns></returns>
        [Route(""), HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        public HttpResponseMessage RedirectToSwaggerUi()
        {
            var httpResponseMessage = new HttpResponseMessage(HttpStatusCode.Found);
            httpResponseMessage.Headers.Location = new Uri("/ui/index", UriKind.Relative);
            return httpResponseMessage;
        }
    }
}
