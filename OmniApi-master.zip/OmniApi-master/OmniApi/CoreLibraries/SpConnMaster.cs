﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmniApi.CoreLibraries
{
    public class SpConnMaster
    {
        public const string GetAccountBalance = "dbo.p_GetAccountBalance";
        public const string GetMiniStatement = "dbo.p_GetMiniStatement";
        public const string MobileNoVerification = "dbo.p_MobileNoVerification";
        public const string OTPVerification = "dbo.p_OTPVerification"; 
        public const string AddEditRegistration = "dbo.p_AddEditRegistration";
        public const string GetAllPropertiesList = "dbo.p_GetAllPropertiesList";
        public const string AddEditShowCase = "dbo.p_AddEditShowCase";
        public const string GetShowCaseByID = "dbo.p_GetShowCaseByID";
        public const string GetAllShowCase = "dbo.p_GetAllShowCase";
        public static  string TokenOperatorID = "";
    }

}