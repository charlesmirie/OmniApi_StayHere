﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Xml;
using Antlr.Runtime.Misc;
using BR.ApplicationBlocks.Data;
using BR.Configuration;
using BR.DBClient;
using BRBase;
using BRControls;
using BRDALLibrary;
using BREntities.CurrencyDenominations;
using BREntities.GroupLoanDisbursement;
using BREntities.LoanCalulator;
using BREntities.LoanDisbSchedules;
using BREntities.LoanInitiationDetail;
using BREntities.LoanIntCalcRule;
using BREntities.LoanPreClosureDetail;
using BREntities.Loans;
using BREntities.ProductLoan;
using BREntities.StandingInstructions;
using BREntities.Transactions;
using BREntities.WFLoanApplications;
using BREntities.WFLoanAppraisal;
using BREntities.WFLoanAppraisals;
using Com.CloudRail.SI.Types;
using Newtonsoft.Json;
using Telegram.Bot.Types;

namespace OmniApi.CoreLibraries
{
    public class OmniCore
    {
        #region Session token management
        static public bool ValidateSessionID(UserInfo usrInfo, out BRDataSet ds_IsTokenValid, params object[] paramArray)
        {

            AuditInfo auditInfo = new AuditInfo();
            auditInfo.ModuleID = BRModule.Client;
            auditInfo.EventID = BROperation.View;
            auditInfo.Status = BRStatus.Successful;
            BRDataSet dsSuperVision = new BRDataSet();
            ds_IsTokenValid = new BRDataSet();
            dsSuperVision = new BRDataSet();
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(7);

            string sessionID = (paramArray.Length > 0 && paramArray[0] != null ? paramArray[0].ToString() : string.Empty);
            string EventID = (paramArray.Length > 1 && paramArray[1] != null ? paramArray[1].ToString() : string.Empty);
            string IpAddress = (paramArray.Length > 2 && paramArray[2] != null ? paramArray[2].ToString() : string.Empty);
            string strFrequency = (paramArray.Length > 3 && paramArray[0] != null ? paramArray[3].ToString() : string.Empty);
            string strTokenDuration = (paramArray.Length > 4 && paramArray[4] != null ? paramArray[4].ToString() : "0");


            arParms[0] = intfDBHelper.CreateNewDBParam("TokenID", SqlDbType.NVarChar, 1000);
            arParms[0].Value = sessionID;
            arParms[1] = intfDBHelper.CreateNewDBParam("EventID", SqlDbType.NVarChar, 10);
            arParms[1].Value = EventID;
            arParms[2] = intfDBHelper.CreateNewDBParam("IpAddress", SqlDbType.NVarChar, 100);
            arParms[2].Value = IpAddress;
            arParms[3] = intfDBHelper.CreateNewDBParam("Frequency", SqlDbType.NVarChar, 20);
            arParms[3].Value = strFrequency;
            arParms[4] = intfDBHelper.CreateNewDBParam("TokenDuration", SqlDbType.NVarChar, 2);
            arParms[4].Value = int.Parse(strTokenDuration);
            arParms[5] = intfDBHelper.CreateNewDBParam("OurBranchID", SqlDbType.NVarChar, 6);
            arParms[5].Value = usrInfo.strBranch;
            arParms[6] = intfDBHelper.CreateNewDBParam("OperatorID", SqlDbType.NVarChar, 15);
            arParms[6].Value = usrInfo.strUser;
            try
            {
                using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                {
                    intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, "p_GatewayAPIAccess", ds_IsTokenValid, new string[] { "APIResponse" }, arParms);
                }

                if (ds_IsTokenValid.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                auditInfo.Status = BRStatus.Failed;
                auditInfo.Message = ex.Message;
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
        }
        #endregion Session token management

        #region API Audit Log
        static public string fn_APIAuditLog(UserInfo usrInfo, string MethodName, string Action, string AuditRespo, string[] strParams, string[] strParamValues, string UniqueAuditID)
        {
            string strAddEditAPIAuditLogXML = string.Empty;

            strAddEditAPIAuditLogXML = strAddEditAPIAuditLogXML + fn_AddEditAPIAuditLogXML(strParams, strParamValues);
            string OpenMethodName = "<" + MethodName + ">";
            string CloseMethodName = "</" + MethodName + ">";
            strAddEditAPIAuditLogXML = strAddEditAPIAuditLogXML.Replace("<New_Record>", OpenMethodName);
            strAddEditAPIAuditLogXML = strAddEditAPIAuditLogXML.Replace("</New_Record>", CloseMethodName);

            BRDataSet ds_AddEditAPIAuditLogXML = new BRDataSet();
            bool AuditRespo_ = false;

            AuditRespo_ = AddEditAPIAuditLog(usrInfo, MethodName, Action, strAddEditAPIAuditLogXML, UniqueAuditID, out ds_AddEditAPIAuditLogXML);
            if (AuditRespo_ == true)
            {
                ds_AddEditAPIAuditLogXML.Namespace = null;
            }
            return ds_AddEditAPIAuditLogXML.GetXml().ToString().Replace("<BRDataSet>", "").Replace("</BRDataSet>", "").Trim();
        }

        static public string fn_APIAuditLog_(UserInfo usrInfo, string MethodName, string Action, string AuditRespo, string strParams, object strParamValues, string UniqueAuditID)
        {
            //string strAddEditAPIAuditLogXML = string.Empty;
            //strAddEditAPIAuditLogXML = JsonConvert.DeserializeXmlNode(strParamValues.ToString()).OuterXml;

            BRDataSet ds_AddEditAPIAuditLogXML = new BRDataSet();
            bool AuditRespo_ = false;

            string objActivityDetails = JsonConvert.SerializeObject(strParamValues);
            XmlDocument xmlObject = JsonConvert.DeserializeXmlNode("{\"root\":" + objActivityDetails.ToString() + "}");

            AuditRespo_ = AddEditAPIAuditLog_(usrInfo, MethodName, Action, xmlObject.InnerXml.ToString(), objActivityDetails, UniqueAuditID, out ds_AddEditAPIAuditLogXML);
            if (AuditRespo_ == true)
            {
                ds_AddEditAPIAuditLogXML.Namespace = null;
            }
            return ds_AddEditAPIAuditLogXML.GetXml().ToString().Replace("<BRDataSet>", "").Replace("</BRDataSet>", "").Trim();
        }

        static public string fn_AddEditAPIAuditLogXML(string[] strParams, string[] strParamValues)
        {
            string Finalstr = string.Empty;
            Finalstr = WriteXML(strParams, strParamValues);
            return Finalstr;
        }

        static public bool AddEditAPIAuditLog(UserInfo usrInfo, string MethodName, string Action, string strAddEditAPIAuditLogXML, string UniqueAuditID, out BRDataSet dsAddEditAPIAuditLogXML)
        {
            AuditInfo auditInfo = new AuditInfo();
            auditInfo.EventID = BROperation.Add;
            auditInfo.Status = BRStatus.Successful;

            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            dsAddEditAPIAuditLogXML = new BRDataSet();

            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(10);
            arParms[0] = intfDBHelper.CreateNewDBParam("MethodName", SqlDbType.NVarChar);
            arParms[0].Value = MethodName;
            arParms[1] = intfDBHelper.CreateNewDBParam("Action", SqlDbType.NVarChar);
            arParms[1].Value = Action;
            arParms[2] = intfDBHelper.CreateNewDBParam("UpdateCount", SqlDbType.Int);
            arParms[2].Value = 2;
            arParms[3] = intfDBHelper.CreateNewDBParam("AuditID", SqlDbType.NVarChar);
            arParms[3].Value = UniqueAuditID;
            arParms[4] = intfDBHelper.CreateNewDBParam("DetailRecords", SqlDbType.Xml);
            arParms[4].Value = strAddEditAPIAuditLogXML;

            try
            {
                using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                {
                    intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, "p_AddEditAPIAuditLog", dsAddEditAPIAuditLogXML, new string[] { "AddEditAPIAuditLog" }, arParms);
                }

                if (dsAddEditAPIAuditLogXML.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                auditInfo.Status = BRStatus.Failed;
                auditInfo.Message = ex.Message;
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                dsAddEditAPIAuditLogXML.Dispose();
            }
        }

        static public bool AddEditAPIAuditLog_(UserInfo usrInfo, string MethodName, string Action, string strAddEditAPIAuditLogXML, string strAddEditAPIAuditLogString, string UniqueAuditID, out BRDataSet dsAddEditAPIAuditLogXML)
        {
            AuditInfo auditInfo = new AuditInfo();
            auditInfo.EventID = BROperation.Add;
            auditInfo.Status = BRStatus.Successful;

            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            dsAddEditAPIAuditLogXML = new BRDataSet();

            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(10);
            arParms[0] = intfDBHelper.CreateNewDBParam("MethodName", SqlDbType.NVarChar);
            arParms[0].Value = MethodName;
            arParms[1] = intfDBHelper.CreateNewDBParam("Action", SqlDbType.NVarChar);
            arParms[1].Value = Action;
            arParms[2] = intfDBHelper.CreateNewDBParam("UpdateCount", SqlDbType.Int);
            arParms[2].Value = 2;
            arParms[3] = intfDBHelper.CreateNewDBParam("AuditID", SqlDbType.NVarChar);
            arParms[3].Value = UniqueAuditID;
            arParms[4] = intfDBHelper.CreateNewDBParam("DetailRecords", SqlDbType.Xml);
            arParms[4].Value = strAddEditAPIAuditLogXML;
            arParms[5] = intfDBHelper.CreateNewDBParam("strDetailRecords", SqlDbType.NVarChar);
            arParms[5].Value = strAddEditAPIAuditLogString;

            try
            {
                SqlConnection conString = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                conString.Open();

                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                intfDBHelper.FillDataset(conString, CommandType.StoredProcedure, "p_AddEditAPIAuditLog", dsAddEditAPIAuditLogXML, new string[] { "AddEditAPIAuditLog" }, arParms);
                conString.Close();
                //}

                if (dsAddEditAPIAuditLogXML.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                auditInfo.Status = BRStatus.Failed;
                auditInfo.Message = ex.Message;
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                dsAddEditAPIAuditLogXML.Dispose();
            }
        }

        static private string WriteXML(string[] strParam, string[] strParamValues)
        {
            StringBuilder sb = new StringBuilder();
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            XmlWriter writer = XmlWriter.Create(sb, settings);
            writer.WriteStartDocument();

            writer.WriteStartElement("New_Record");//New_Record Start

            for (int i = 0; i < strParam.Length; i++)
            {
                writer.WriteElementString(strParam[i], strParamValues[i]);
            }
            writer.WriteEndDocument();//New_Record End

            writer.Flush();
            writer.Close();

            return System.Convert.ToString(sb.Replace("&gt;", ">").Replace("&lt;", "<"));
        }

        public static BRDataSet fn_SplitDiffDataSets(BRBaseDataSet dsMainRecord, string strSupTableName)
        {
            BRDataSet dsSupervision = new BRDataSet();
            dsSupervision.Tables.Add(new DataTable(strSupTableName));
            if (dsMainRecord.Tables.Contains(strSupTableName))
            {
                dsSupervision.Tables[strSupTableName].Merge(dsMainRecord.Tables[strSupTableName], false, MissingSchemaAction.Add);
                dsMainRecord.Tables.Remove(strSupTableName);
            }
            return dsSupervision;
        }

        #endregion API Audit Log

        #region GetAllPropertiesList
        public static bool AddPropertyType(UserInfo usrInfo, string propertyTypeName, string propertyTypeDesc, string propertySubTypeID, string propertyID out BRDataSet ds_PropertiesList)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_PropertiesList = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(3);
            arParms[0] = intfDBHelper.CreateNewDBParam("PropertyID", SqlDbType.NVarChar, 50);
            arParms[0].Value = PropertyID;
            try
            { 
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();

                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.GetShowCase, ds_PropertiesList, new string[] { "APIResponse", "GetAllPropertiesList" }, arParms);
                connection.Close();

                if (ds_PropertiesList.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_PropertiesList.Dispose();
            }
        }
        #endregion GetAllPropertiesList

        #region Registration 
        //public static bool Registration_(UserInfo usrInfo, out BRDataSet ds_GetRenewalModeID)
        //{

        //    IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
        //    ds_GetRenewalModeID = new BRDataSet();
        //    IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(3);
        //    //arParms[0] = intfDBHelper.CreateNewDBParam("OurBranchID", SqlDbType.NVarChar, 6);
        //    //arParms[0].Value = OurBranchID;
        //    try
        //    {
        //        using (IDbConnection connection = DBClient.GetConnection(usrInfo))
        //        {
        //            intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.GetRenewalModeID, ds_GetRenewalModeID, new string[] { "APIResponse", "GetRenewalModeID" }, arParms);
        //        }

        //        if (ds_GetRenewalModeID.Tables[0].Rows.Count == 0)
        //        {
        //            return false;
        //        }

        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
        //    }
        //    finally
        //    {
        //        ds_GetRenewalModeID.Dispose();
        //    }
        //}

        public static bool Registration(UserInfo usrInfo, string mobileNo, string location, bool isActive, bool isValidated, string email, string OTP, string userID,
            string name, string IMEI, out BRDataSet ds_Registration)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_Registration = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            arParms[0] = intfDBHelper.CreateNewDBParam("mobileNo", SqlDbType.NVarChar, 15);
            arParms[0].Value = mobileNo;
            arParms[1] = intfDBHelper.CreateNewDBParam("location", SqlDbType.NVarChar, 4000);
            arParms[1].Value = location;
            arParms[2] = intfDBHelper.CreateNewDBParam("isActive", SqlDbType.Bit);
            arParms[2].Value = isActive;
            arParms[3] = intfDBHelper.CreateNewDBParam("isValidated", SqlDbType.Int);
            arParms[3].Value = isValidated;
            arParms[4] = intfDBHelper.CreateNewDBParam("email", SqlDbType.NVarChar, 20);
            arParms[4].Value = email;
            arParms[5] = intfDBHelper.CreateNewDBParam("OTP", SqlDbType.NVarChar, 20);
            arParms[5].Value = OTP;
            arParms[6] = intfDBHelper.CreateNewDBParam("actionID", SqlDbType.Bit);
            arParms[6].Value = 1;
            arParms[7] = intfDBHelper.CreateNewDBParam("userID", SqlDbType.NVarChar, 20);
            arParms[7].Value = userID;
            arParms[8] = intfDBHelper.CreateNewDBParam("name", SqlDbType.NVarChar, 20);
            arParms[8].Value = name;
            arParms[9] = intfDBHelper.CreateNewDBParam("IMEI", SqlDbType.NVarChar, 20);
            arParms[9].Value = IMEI;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.AddEditRegistration, ds_Registration, new string[] { "APIResponse", "Registration" }, arParms);
                connection.Close();
                //}

                if (ds_Registration.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_Registration.Dispose();
            }
        }
        public static bool OTPVerification(UserInfo usrInfo, string OTPCode, out BRDataSet ds_OTPVerification)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_OTPVerification = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            arParms[0] = intfDBHelper.CreateNewDBParam("OTPCode", SqlDbType.NVarChar, 15);
            arParms[0].Value = OTPCode;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.OTPVerification, ds_OTPVerification, new string[] { "APIResponse", "OTPVerification" }, arParms);
                connection.Close();
                //}

                if (ds_OTPVerification.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_OTPVerification.Dispose();
            }
        }
        public static bool MobileNoVerification(UserInfo usrInfo, string mobileNo, out BRDataSet ds_MobileNoVerification)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_MobileNoVerification = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            arParms[0] = intfDBHelper.CreateNewDBParam("mobileNo", SqlDbType.NVarChar, 15);
            arParms[0].Value = mobileNo;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.MobileNoVerification, ds_MobileNoVerification, new string[] { "APIResponse", "MobileNoVerification" }, arParms);
                connection.Close();
                //}

                if (ds_MobileNoVerification.Tables[0].Rows.Count == 0)
                {
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_MobileNoVerification.Dispose();
            }
        }

        #endregion Registration    

        #region showCaseID          
        public static bool AddShowCase(UserInfo usrInfo, string showCaseID, string showCaseTitle, string showCaseMessage, int imageID, string userID,
            int actionID, int isActive, out BRDataSet ds_AddEditShowCase)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_AddEditShowCase = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);

            arParms[0] = intfDBHelper.CreateNewDBParam("showCaseID", SqlDbType.NVarChar, 20);
            arParms[0].Value = showCaseID;
            arParms[1] = intfDBHelper.CreateNewDBParam("showCaseTitle", SqlDbType.NVarChar, 200);
            arParms[1].Value = showCaseTitle;
            arParms[2] = intfDBHelper.CreateNewDBParam("showCaseMessage", SqlDbType.NVarChar, 1000);
            arParms[2].Value = showCaseMessage;
            arParms[3] = intfDBHelper.CreateNewDBParam("imageID", SqlDbType.BigInt);
            arParms[3].Value = imageID;
            arParms[4] = intfDBHelper.CreateNewDBParam("userID", SqlDbType.NVarChar, 50);
            arParms[4].Value = userID;
            arParms[5] = intfDBHelper.CreateNewDBParam("actionID", SqlDbType.Int);
            arParms[5].Value = actionID;
            arParms[6] = intfDBHelper.CreateNewDBParam("isActive", SqlDbType.Int);
            arParms[6].Value = isActive;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.AddEditShowCase, ds_AddEditShowCase, new string[] { "APIResponse", "AddEditShowCase" }, arParms);
                connection.Close();
                // }

                if (ds_AddEditShowCase.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_AddEditShowCase.Dispose();
            }
        }
        public static bool EditShowCase(UserInfo usrInfo, string showCaseID, string showCaseTitle, string showCaseMessage, int imageID, int isActive, string userID, int actionID, out BRDataSet ds_AddEditShowCase)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_AddEditShowCase = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            arParms[0] = intfDBHelper.CreateNewDBParam("showCaseID", SqlDbType.NVarChar, 20);
            arParms[0].Value = showCaseID;
            arParms[1] = intfDBHelper.CreateNewDBParam("showCaseTitle", SqlDbType.NVarChar, 200);
            arParms[1].Value = showCaseTitle;
            arParms[2] = intfDBHelper.CreateNewDBParam("showCaseMessage", SqlDbType.NVarChar, 1000);
            arParms[2].Value = showCaseMessage;
            arParms[3] = intfDBHelper.CreateNewDBParam("imageURL", SqlDbType.BigInt);
            arParms[3].Value = imageID;
            arParms[4] = intfDBHelper.CreateNewDBParam("userID", SqlDbType.NVarChar, 50);
            arParms[4].Value = userID;
            arParms[5] = intfDBHelper.CreateNewDBParam("actionID", SqlDbType.Int);
            arParms[5].Value = actionID;
            arParms[6] = intfDBHelper.CreateNewDBParam("isActive", SqlDbType.Int);
            arParms[6].Value = isActive;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.AddEditShowCase, ds_AddEditShowCase, new string[] { "APIResponse", "AddEditShowCase" }, arParms);
                connection.Close();
                // }

                if (ds_AddEditShowCase.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_AddEditShowCase.Dispose();
            }
        }

        public static bool GetShowCaseByID(UserInfo usrInfo, int showCaseID, out BRDataSet ds_GetShowCase)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_GetShowCase = new BRDataSet();
            IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            arParms[0] = intfDBHelper.CreateNewDBParam("showCaseID", SqlDbType.BigInt);
            arParms[0].Value = showCaseID;
            try
            {
                //using (IDbConnection connection = DBClient.GetConnection(usrInfo))
                //{
                //    intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.GetShowCase, ds_GetShowCase, new string[] { "APIResponse", "GetShowCase" }, arParms);
                //}

                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.GetShowCaseByID, ds_GetShowCase, new string[] { "APIResponse", "GetShowCase" }, arParms);
                connection.Close();

                if (ds_GetShowCase.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_GetShowCase.Dispose();
            }
        }

        public static bool GetAllShowCase(UserInfo usrInfo, out BRDataSet ds_GetShowCase)
        {
            IDBHelper intfDBHelper = DBClient.GetDBHelper(usrInfo);
            ds_GetShowCase = new BRDataSet();
            //IDataParameter[] arParms = intfDBHelper.CreateDBParamsArray(30);
            //arParms[0] = intfDBHelper.CreateNewDBParam("showCaseID", SqlDbType.BigInt);
            //arParms[0].Value = showCaseID;
            try
            {
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connString"].ToString());
                connection.Open();
                intfDBHelper.FillDataset(connection, CommandType.StoredProcedure, SpConnMaster.GetAllShowCase, ds_GetShowCase, new string[] { "APIResponse", "GetShowCase" });
                connection.Close();

                if (ds_GetShowCase.Tables[0].Rows.Count == 0)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                throw DBClientUtils.GetDBErrorMessages(ex, usrInfo.strUser, usrInfo.strSystem);
            }
            finally
            {
                ds_GetShowCase.Dispose();
            }
        }

        #endregion showCaseID
    }
}