﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Text;
using System.Text.RegularExpressions;
using BR.Configuration;
using MySql.Data.MySqlClient; 
using System.Data; 
using BR.ApplicationBlocks.Data; 

namespace OmniApi.Classes
{
    public class ReturnResponse
    {
        public string WebServiceStatus { get; set; }
        public string AccessToken { get; set; }
        public string TokenExpiry { get; set; }
        public string ErrorNo { get; set; }
        public string ErrorMessage { get; set; }

        public static string myResponse = "";

        public string transferToPool(string src_acc, string ex_tran_ref, string amount, string tran_timestamp, string payment_details)
        {
            try
            {
                string xml = string.Empty;
                string url = "https://10.253.1.25:8181/ZWS/zanaco/services/transferToPool";
                string actionURL = BRConfigurationManager.BRAppSettings["Flex_transferToPool_actionURL"].ToString();
                string inst_id = BRConfigurationManager.BRAppSettings["Flex_inst_id"].ToString();
                string password = BRConfigurationManager.BRAppSettings["Flex_Kifunguo"].ToString();
                string tran_type = BRConfigurationManager.BRAppSettings["Flex_tran_type"].ToString();
                string ccy = BRConfigurationManager.BRAppSettings["Flex_ccy"].ToString();
                try
                {
                    xml = fn_transferToPool(inst_id, password, src_acc, ex_tran_ref, tran_type, ccy, amount, tran_timestamp, payment_details);
                    //By pass the ssl cert
                    InitiateSSLTrust();
                    var response = httpPost(url, actionURL, xml);

                    string responseStatus = string.Empty;
                    responseStatus = response["OK"];
                    switch (responseStatus)
                    {
                        case "YES":
                            return response["RESPONSE"];
                        default:
                            if (response.ContainsKey("TIMEOUT"))
                            {
                                return response["TIMEOUT"];
                            }

                            return response["MESSAGE"];
                    }
                }

                catch (Exception ex)
                {
                    return "";
                }
            }
            catch (Exception ex)
            {
                return "Error Getting Response";
            }
            finally
            {
            }
        }

        private string fn_transferToPool(string inst_id, string password, string src_acc, string ex_tran_ref, string tran_type, string ccy, string amount, string tran_timestamp, string payment_details)
        {
            try
            {
                //MethodName = "fn_transferToPool";
                string xml = @"<payment xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""><onlineFTRequest id=""transferToPool""><inst_id>" + inst_id + @"</inst_id><password>" + password + @"</password><src_acc>" + src_acc + @"</src_acc><ex_tran_ref>" + ex_tran_ref + @"</ex_tran_ref><tran_type>" + tran_type + @"</tran_type><ccy>" + ccy + @"</ccy><amount>" + amount + @"</amount><tran_timestamp>" + tran_timestamp + @"</tran_timestamp><payment_details>" + payment_details + @"</payment_details></onlineFTRequest></payment>";
                return xml;
            }
            catch (Exception ex)
            {
                //WriteToErrorFile(Convert.ToString(ex.Message), "ZanacoFlex:fn_transferToPool()");
                return "";
            }
            finally
            {
            }
        }

        private static void InitiateSSLTrust()
        {
            try
            {
                //Change SSL checks so that all checks pass
                ServicePointManager.ServerCertificateValidationCallback =
                   new RemoteCertificateValidationCallback(
                        delegate
                        { return true; }
                    );
            }
            catch (Exception ex)
            {
                //ActivityLog.InsertSyncActivity(ex);
            }
        }

        private static Dictionary<string, string> httpPost(string url, string action, string xml)
        {
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(url);
                string responseJson = string.Empty;
                string method = string.Empty;

                string myRequest = xml;
                string myUrl = url;
                System.IO.StreamWriter myWriter = null;// it will open a http connection with provided url

                System.Net.HttpWebRequest objRequest = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(myUrl);//send data using objxmlhttp object
                objRequest.Method = "POST";
                objRequest.Headers["Authorization"] = "Basic " + Convert.ToBase64String(Encoding.Default.GetBytes("Test:test_zanaco$1")); // ZANACO FLEX

                var bytes_ = Encoding.ASCII.GetBytes(myRequest);
                objRequest.ContentType = "application/xml";
                objRequest.ContentLength = bytes_.Length;

                myWriter = new System.IO.StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(myRequest);//send data
                myWriter.Close();//closed the myWriter object
                System.Net.HttpWebResponse objResponse = (System.Net.HttpWebResponse)objRequest.GetResponse();//receive the responce from objxmlhttp object 

                using (System.IO.StreamReader sr = new System.IO.StreamReader(objResponse.GetResponseStream()))
                {
                    myResponse = sr.ReadToEnd();
                    var dictionary = new Dictionary<string, string>();
                    dictionary.Add("OK", "YES");
                    dictionary.Add("RESPONSE", myResponse);
                    dictionary.Add("REQUEST", xml);
                    return dictionary;
                }
            }
            catch (WebException wex)
            {
                string message = wex.Message;
                string pageContent = new StreamReader(wex.Response.GetResponseStream()).ReadToEnd().ToString();
                var dictionary = new Dictionary<string, string>();
                switch (wex.Status)
                {
                    case WebExceptionStatus.ProtocolError:

                        HttpWebResponse response = (HttpWebResponse)wex.Response;
                        StreamReader responseReader =
                            new StreamReader(response.GetResponseStream());
                        string responseFromServer = responseReader.ReadToEnd();
                        switch (response.StatusCode)
                        {
                            case HttpStatusCode.InternalServerError:
                                response.Close();
                                dictionary.Add("OK", "NO");
                                dictionary.Add("MESSAGE", message);
                                dictionary.Add("REQUEST", xml);
                                return dictionary;
                        }
                        break;

                    case WebExceptionStatus.Timeout:
                        dictionary.Add("OK", "NO");
                        dictionary.Add("MESSAGE", message);
                        dictionary.Add("REQUEST", xml);
                        return dictionary;
                }
                dictionary.Add("OK", "NO");
                dictionary.Add("MESSAGE", wex.Message);
                dictionary.Add("REQUEST", xml);
                //WriteToErrorFile(Convert.ToString(wex.Message), "HttpInterface:httpPost: url:" + url + " action:" + action + " xml:" + xml);
                return dictionary;
            }
        }


    }

    public static class StringExtensionMethods
    { 
        public static IEnumerable<IList<T>> SplitBy<T>(this IEnumerable<T> source,
                                              Func<T, bool> startPredicate,
                                              Func<T, bool> endPredicate,
                                              bool includeDelimiter)
        {
            var l = new List<T>();
            foreach (var s in source)
            {
                if (startPredicate(s))
                {
                    if (l.Any())
                    {
                        l = new List<T>();
                    }
                    l.Add(s);
                }
                else if (l.Any())
                {
                    l.Add(s);
                }

                if (endPredicate(s))
                {
                    if (includeDelimiter)
                    {
                        yield return l;
                    }
                    else
                    {
                        yield return l.GetRange(1, l.Count - 2);
                    }

                    l = new List<T>();
                }
            }
        }
        public static List<string> EverythingBetween(this string source, string start, string end)
        {
            var results = new List<string>();

            string pattern = string.Format(
                "{0}({1}){2}",
                Regex.Escape(start),
                ".+?",
                 Regex.Escape(end));

            foreach (Match m in Regex.Matches(source, pattern))
            {
                results.Add(m.Groups[1].Value);
            }

            return results;
        }
    }

}