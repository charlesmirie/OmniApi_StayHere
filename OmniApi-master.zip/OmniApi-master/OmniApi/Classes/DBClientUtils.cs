﻿ 
using System;
using System.Data; 
using System.Data.SqlClient;
using System.IO;
using BR.ApplicationBlocks.Data;
using BR.Configuration;
using MySql.Data.MySqlClient;

namespace BR.DBClient
{
    public static class DBClientUtils
    {
        public static int UpdateMandatory(DataTable dTable, IDBHelper intfDBHelper, IDbTransaction transaction, string spName, bool bNewRecord, params object[] keyValues)
        {
            DataRow dataRow = dTable.Rows[0];
            dTable.Columns.Add("NewRecord", typeof(bool));
            dataRow["NewRecord"] = bNewRecord;
            if (keyValues != null)
            {
                if (keyValues.Length % 2 != 0)
                {
                    throw new DataException("uneven keyValues");
                }

                for (int i = 0; i < keyValues.Length; i += 2)
                {
                    dataRow[(string)keyValues[0]] = keyValues[1];
                }
            }

            intfDBHelper.ExecuteScalarTypedParams(transaction, spName, dataRow);
            return 1;
        }

        public static Exception GetDBErrorMessages(Exception ex, string UserID, string strSystem)
        {
            //IL_0176: Unknown result type (might be due to invalid IL or missing references)
            //IL_017c: Expected O, but got Unknown
            if (BRConfigurationManager.BRAppSettings["ErrorLogPath"].ToString() != "")
            {
                string text = BRConfigurationManager.BRAppSettings["ErrorLogPath"].ToString() + strSystem + "\\";
                Directory.CreateDirectory(text);
                string contents = string.Concat("User ID:", UserID, Environment.NewLine, "Error Message:", ex.Message, Environment.NewLine, "Date:", DateTime.Now, Environment.NewLine, "--------------------------", Environment.NewLine);
                File.AppendAllText(text + UserID + DateTime.Now.ToString("yyyy-MM-dd").Replace("-", "") + ".txt", contents);
            }

            string text2 = ex.Message.Replace("\r\n", "");
            text2 = text2.Replace('\n', ' ');

            if (ex.Message.IndexOf("EX") != -1)
            {
                return ex;
            }

            if (ex is SqlException)
            {
                //SqlException ex2 = (SqlException)ex;
                //return new Exception("EXDB" + ex2.Number);
                return new Exception("EXMSG[" + text2 + "]");
            }
             
            if (ex is MySqlException)
            {
                MySqlException ex3 = (MySqlException)ex;
                return new Exception("EXDB" + ex3.Number);
            } 

            return new Exception("EXMSG[" + text2 + "]");
        }

        public static Exception GetErrorMessages(Exception ex)
        {
            if (ex.Message.IndexOf("EX") != -1)
            {
                return ex;
            }

            throw new Exception("EXUI003460");
        }
    }
}
#if false // Decompilation log
'67' items in cache
------------------
Resolve: 'mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Found single assembly: 'mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Load from: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\mscorlib.dll'
------------------
Resolve: 'System.Data, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Found single assembly: 'System.Data, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Load from: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Data.dll'
------------------
Resolve: 'System.Data.OracleClient, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Could not find by name: 'System.Data.OracleClient, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
------------------
Resolve: 'MySQL.Data, Version=1.0.4.22018, Culture=neutral, PublicKeyToken=null'
Found single assembly: 'MySQL.Data, Version=1.0.4.22018, Culture=neutral, PublicKeyToken=null'
Load from: 'D:\Charles\CM\OmniApi\OmniApi\OmniApi\bin\MySQL.Data.dll'
------------------
Resolve: 'System.Xml, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Found single assembly: 'System.Xml, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Load from: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Xml.dll'
------------------
Resolve: 'BRBase, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null'
Found single assembly: 'BRBase, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null'
Load from: 'D:\Charles\CM\OmniApi\OmniApi\OmniApi\bin\BRBase.dll'
------------------
Resolve: 'System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
Found single assembly: 'System.Data, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089'
WARN: Version mismatch. Expected: '2.0.0.0', Got: '4.0.0.0'
Load from: 'C:\Program Files (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\System.Data.dll'
------------------
Resolve: 'BRConfiguration, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null'
Found single assembly: 'BRConfiguration, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null'
Load from: 'D:\Charles\CM\OmniApi\OmniApi\OmniApi\bin\BRConfiguration.dll'
------------------
Resolve: 'BRNetSecurity, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null'
Found single assembly: 'BRNetSecurity, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null'
Load from: 'D:\Charles\CM\OmniApi\OmniApi\OmniApi\bin\BRNetSecurity.dll'
#endif
