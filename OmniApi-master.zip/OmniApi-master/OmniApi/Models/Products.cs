﻿using System.Collections.Generic;

namespace WebApi.Jwt.Models
{
    public class ProductsModel
    {
        public ICollection<Products> data { get; set; } 
        //public ICollection<GetAllProducts> data_ { get; set; } 
    }
    public class Products
    {
        //public string SessionID { get; set; }
        public string ProductID { get; set; }
        public string CurrencyID { get; set; }
        public string ProductType { get; set; }

        public override string ToString()
        {
            return "{ \"ProductID\": " + this.ProductID + ", \"CurrencyID\": " + this.CurrencyID + ", \"ProductType\": " + this.ProductType + " }";
        }
    }

    public class GetAllProducts
    {
        public string OurBranchID { get; set; } 
        public override string ToString()
        {
            return "{ \"OurBranchID\": " + this.OurBranchID  + " }";
        }
    }
}