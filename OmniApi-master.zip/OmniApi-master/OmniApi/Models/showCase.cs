﻿using System.Collections.Generic;

namespace WebApi.Jwt.Models
{
    public class showCaseModel
    {
        public ICollection<AddShowCase> data { get; set; }
        public ICollection<EditShowCase> myData { get; set; }
        // public ICollection<GetShowCase> data { get; set; }
    }

    public class AddShowCase
    { 
        public string showCaseTitle { get; set; }
        public string showCaseMessage { get; set; }
        public int imageID { get; set; }
        public string userID { get; set; } 
        public override string ToString()
        {
            return "{ \"showCaseTitle\": " + this.showCaseTitle +
                      ", \"showCaseMessage\": " + this.showCaseMessage +
                      ", \"imageID\": " + this.imageID +
                      ", \"userID\": " + this.userID +
                     " }";
        }
    }

    public class EditShowCase
    { 
        public string showCaseID { get; set; }
        public string showCaseTitle { get; set; }
        public string showCaseMessage { get; set; }
        public int imageID { get; set; } 
        public string userID { get; set; }
        public int isActive { get; set; }
        public int actionID { get; set; } 
        public override string ToString()
        {
            return "{ \"showCaseID\": " + this.showCaseID +
                      ", \"showCaseTitle\": " + this.showCaseTitle +
                      ", \"showCaseMessage\": " + this.showCaseMessage +
                      ", \"imageID\": " + this.imageID +
                      ", \"userID\": " + this.userID +
                      ", \"isActive\": " + this.isActive +
                      ", \"actionID\": " + this.actionID + 
                     " }";
        }
    }
    public class GetShowCaseByID
    { 
        public int showCaseID { get; set; } 
        public override string ToString()
        {
            return "{ \"showCaseID\": " + this.showCaseID  +
                     " }";
        }
    }
    public class GetAllShowCase
    { 
    }
}