﻿using System;
using System.Collections.Generic;

namespace WebApi.Jwt.Models
{
    public class PropertiesModel
    {
        public ICollection<GetAllPropertiesList> data { get; set; }
    //    public ICollection<AddPropertyType> data_ { get; set; }
    //    public ICollection<GetPropertyTypeByID> data { get; set; }
    //    public ICollection<GetAllPropertyType> data { get; set; }
    }

    public class GetAllPropertiesList
    {
        //public string SessionID { get; set; }
        public string PropertyID { get; set; } 
        public override string ToString()
        {
            return "{ \"PropertyID\": " + this.PropertyID +                      
                    " }";
        }
    }
    public class AddPropertyType
    { 
        public string propertyTypeName { get; set; }
        public string propertyTypeDesc { get; set; }
        public string propertySubTypeID { get; set; }
        public string propertyID { get; set; }
        public int isActive { get; set; }
        public int actionID { get; set; }
        public override string ToString()
        {
            return "{ \"propertyTypeName\": " + this.propertyTypeName +
                      ", \"propertyTypeDesc\": " + this.propertyTypeDesc +
                      ", \"propertySubTypeID\": " + this.propertySubTypeID +
                      ", \"propertyID\": " + this.propertyID + 
                      ", \"isActive\": " + this.isActive +
                      ", \"actionID\": " + this.actionID +
                     " }";
        }
    }

    public class GetPropertyTypeByID
    {
        public int propertyTypeID { get; set; } 
        public override string ToString()
        {
            return "{ \"propertyTypeID\": " + this.propertyTypeID + 
                     " }";
        }
    }
    public class GetAllPropertyType
    { 
    }
}