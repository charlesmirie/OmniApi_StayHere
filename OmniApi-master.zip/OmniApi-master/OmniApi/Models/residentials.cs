﻿using Microsoft.Ajax.Utilities;
using System.Collections.Generic;

namespace WebApi.Jwt.Models
{
    public class residentialsModel
    {
        public ICollection<residentials> data { get; set; }
    }

    public class residentials
    {
        //public string SessionID { get; set; }
        public string mobileNo { get; set; }
        public string location { get; set; }
        public bool isActive { get; set; } = false;
        public bool isValidated { get; set; } = false;
        public string email { get; set; }
        public string OTP { get; set; }
        public string userID { get; set; }
        public string name { get; set; }
        public string IMEI { get; set; }
        public override string ToString()
        {
            return "{ \"mobileNo\": " + this.mobileNo +
                     ", \"location\": " + this.location +
                     ", \"email\": " + this.email +
                     ", \"OTP\": " + this.OTP +
                     ", \"isValidated\": " + this.isValidated +
                     ", \"isActive\": " + this.isActive +
                     ", \"userID\": " + this.userID +
                     ", \"name\": " + this.name +
                     ", \"IMEI\": " + this.IMEI +
                    " }";
        }
    }  
}